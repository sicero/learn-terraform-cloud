import boto3
import random
import string

# Initialize the DynamoDB client
dynamodb = boto3.client('dynamodb', region_name='your-region')

# Specify the DynamoDB table name
table_name = 'YourDynamoDBTableName'

# Generate and insert synthetic data into the table
for _ in range(10):  # Insert 10 items as an example
    item = {
        'ID': {'N': str(random.randint(1, 1000))},
        'Name': {'S': ''.join(random.choices(string.ascii_letters, k=10))},
        # Add more attributes as needed
    }

    dynamodb.put_item(TableName=table_name, Item=item)
